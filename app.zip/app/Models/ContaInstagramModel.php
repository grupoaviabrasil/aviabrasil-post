<?php

namespace App\Models;

use CodeIgniter\Model;

class ContaInstagramModel extends Model
{
    protected $table            = 'contas_instagram';
    protected $primaryKey       = 'id';
    protected $useTimestamps    = true;
    protected $allowedFields    = [
        'usuario_id',
        'instagram_user_id',
        'access_token',
        'token_expira_em',
        'status_conexao',
    ];
}
